package com.cuaresma;
import java.lang.Object; 
public class Cars {
	public static void main(String[] args) {
		OpeningDay car1 = new OpeningDay();
		Carwash car2 = new Carwash();

		//First Driver
		car1.getCar("Van");
		car1.getShowerDuration(10);
		car1.getShampooLiter(1.5);
		car1.getWashing("Washing");
		car1.getDryCar("Drying car");
		car1.getVacuumDuration(10);
		car1.getTires("Applying tire black");
		car1.getPayment(1500);
		System.out.println("Enter vehicle: "  + car1.setCar());
		System.out.println("Shower Duration: " + car1.setShowerTime() + " minutes");
		System.out.println("Shampoo Liter: " + car1.setShampoo() + " Liters");
		System.out.println( car1.setWash() +"");
		System.out.println( car1.setDry() + "");
		System.out.println("Vacuum Duration: " + car1.setVacuumTime() + " minutes");
		System.out.println( car1.setTires() +"");
		System.out.println( "Payment: " + car1.setPayment() + "Pesos");
		System.out.println("Driver comes 4 times a month, total amount: " + car1.pay(1500 + 1500 + 1500 + 1500) + " Pesos");
	
		System.out.println("\n");
		//Second Driver
		car2.getCar("SUV");
		car2.getShowerDuration(7);
		car2.getShampooLiter(1.3);
		car2.getWashing("Rinsing off");
		car2.getDryCar("Wiping off"); 
		car2.getVacuumDuration(7);
		car2.getTires("Applying tire black");
		car2.getPayment(1200);
		System.out.println("Enter vehicle: " + car2.setCar());
		System.out.println("Shower Duration: " + car2.setShowerTime() + " minutes");
		System.out.println("Shampoo Liter: " + car2.setShampoo() + " Liters");
		System.out.println(car2.setWash());
		System.out.println(car2.setDry());
		System.out.println("Vacuum Duration: " + car2.setVacuumTime() + " minutes");
		System.out.println("Payment: " + car2.setPayment() + " Pesos");
		System.out.println("Driver comes 3 times a month, total amount: " + car2.pay(1200, 1200, 1200) + " Pesos");
		
		
	}
}




