package com.cuaresma;

public class OpeningDay extends Carwash{

	public OpeningDay() {
		
	}
	public OpeningDay(String car, int showerDuration, double carShampoo, String postWashing, String dryCar, int vacuumDuration, String tires, int userPayment) {
		super(car, showerDuration, carShampoo, postWashing, dryCar, vacuumDuration, tires, userPayment);
	}
	public int pay(int ... a) {
		int total = 0;
		for(int payment : a) {
			total = total + payment;
		}
		return total;
	}
	public int pay(int pay1, int pay2, int pay3) {
		return pay1 + pay2 + pay3;
	}
	public int pay(int pay1, int pay2, int pay3, int pay4) {
		return pay1 + pay2 + pay3+ pay4;
	}
}